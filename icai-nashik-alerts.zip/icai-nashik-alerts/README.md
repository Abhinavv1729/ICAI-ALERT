# ICAI Nashik: New Batch → Telegram Alert

Monitors the public [ICAI Launch Batch Details](https://www.icaionlineregistration.org/launchbatchdetail.aspx) site:

- **Region:** Western Region (WIRC/WRO)
- **POU:** Nashik / Nasik
- **Course:** Every available course option
- **Notifications:** One Telegram alert for each *new* batch
- **Deduplication:** Stores known batch IDs in `state.json`. On its first successful run it **baselines existing batches** and sends a monitor-started confirmation, not dozens of false new-batch alerts.

**Important:** The ICAI website is an old ASP.NET app. The monitor interacts with the actual dropdowns in headless Chromium, not just the initial page. We could verify the public page structure but could not fully exercise the site's filtered results in the build environment. The included diagnostics will reveal if ICAI uses a different batch-table structure or changes its UI. Please run the first manual check and verify it succeeds.

## Option A — GitHub Actions (no always-on computer required)

1. Create a Telegram bot: open **@BotFather** on Telegram, send `/newbot`, follow its steps, copy the token. **Don't publish the token.**
2. Open your new bot and press **Start** or send `/start`.
3. Open `https://api.telegram.org/bot<YOUR_TOKEN>/getUpdates` in your browser after messaging the bot. Find `message.chat.id` in the response. That's your **TELEGRAM_CHAT_ID** (may be negative for a group).
4. Create a **new GitHub repository** (public is often better for Actions billing; the repository has no secrets in its code; the batch history is public). Upload the contents of this folder, including the hidden `.github/workflows/monitor.yml` file, onto the **main/default branch**. In GitHub UI: **Add file → Upload files**; make sure nested directories remain intact. Alternatively use `git add . && git commit && git push`.
5. In the repository open **Settings → Secrets and variables → Actions → New repository secret**. Add two secrets:
   - `TELEGRAM_BOT_TOKEN` — the token from BotFather
   - `TELEGRAM_CHAT_ID` — the chat ID from getUpdates
6. Under **Settings → Actions → General → Workflow permissions**, enable **Read and write permissions** (or configure GitHub's equivalent). This lets the monitor commit its `state.json` history without re-notifying you every run.
7. Go to **Actions → ICAI Nashik Batch Alerts → Run workflow**. Watch the logs. First successful run sends **monitor active** and saves the current batch baseline in `state.json`. Thereafter new batches generate alerts automatically.

The workflow is set to **every five minutes** (UTC cron `*/5 * * * *`). GitHub's scheduled jobs are *best effort*: runs may start late or occasionally be dropped, especially under load, and inactive repositories may have schedules disabled. Usage limits/billing may apply, particularly for private repositories. This is **not a guarantee of an exactly five-minute alert**. For more dependable 24/7 monitoring, run Option B on an always-on VPS.

### Troubleshooting Actions

- **Message not received:** send `/start` to your bot, confirm both exact secrets, and run `python monitor.py --test-alert` on your computer (with environment variables set) or use the Telegram API URL to verify `chat.id`.
- **Permission denied on `git push`:** change workflow permissions to read/write, then manually rerun. If the state doesn't commit, duplicate alerts may occur next run.
- **Unrecognized table:** open failed Action → **Artifacts → icai-monitor-debug** and inspect `unrecognized_*.png`/`.html`. ICAI's table layout may require tweaking `parse_batch_html` in `monitor.py`. No alert is sent when the results cannot be parsed confidently.
- **Region/POU option not found:** inspect the workflow logs for option values. ICAI may have renamed a region/POU or temporarily changed the dropdown logic.
- **No alerts for old batches:** intentional. The first successful run establishes a baseline; only later batches send new-batch notifications.

## Option B — persistent Docker service (VPS / Linux server)

Requires Docker and Docker Compose. Copy this project to your always-on server. Then:

```bash
cp .env.example .env
# Edit .env to insert actual TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID
mkdir -p data debug
docker compose up -d --build
docker compose logs -f
```

This keeps Chromium-based monitoring in a long-running container and restarts after server reboots. `data/state.json` persists batch history. It checks every `POLL_MINUTES` (default 5). Hosting, power, connectivity, ICAI uptime, and server costs remain your responsibility. Stop with `docker compose down`.

## Option C — run on your computer

```bash
python -m pip install -r requirements.txt
python -m playwright install chromium
# Set TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID in your shell
python monitor.py --test-alert
python monitor.py --dry-run --diagnose
python monitor.py --watch
```

The `--dry-run` mode is useful for verifying that **Nashik batch rows** are actually detected without changing the database or sending anything. `--watch` polls continuously while the process is running.

## Behavior / limitations

- Only public batch listings are checked. It does **not** log in, reserve a seat, register you, or guarantee that a batch still has vacancies.
- The script never alerts solely on any page change, empty page, navigation, or unrelated table.
- If a batch's available-seat count changes, it won't repeat the alert if its batch number stayed the same.
- If the website is down, returns a CAPTCHA, changes the dropdown names/table markup, or blocks cloud IPs, checks will fail; review logs. Use the diagnostics to adjust selectors if needed.
- Please respect ICAI's website policies, avoid lowering the five-minute polling interval, and don't attempt to bypass CAPTCHAs or access restrictions.
- No WhatsApp integration is configured. Telegram is used because private bot notifications are straightforward and avoid relying on an unofficial WhatsApp automation service.

### Windows PowerShell quick start (optional local test)

```powershell
py -m pip install -r requirements.txt
py -m playwright install chromium
$env:TELEGRAM_BOT_TOKEN = "YOUR_REAL_BOT_TOKEN"
$env:TELEGRAM_CHAT_ID = "YOUR_CHAT_ID"
py monitor.py --test-alert
py monitor.py --dry-run --diagnose
```

Never paste your bot token into public issues, screenshots, commits, or shared chat messages.
